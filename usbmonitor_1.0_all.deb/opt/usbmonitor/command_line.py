from usbmonitor import device_event
def main():
    device_event()
